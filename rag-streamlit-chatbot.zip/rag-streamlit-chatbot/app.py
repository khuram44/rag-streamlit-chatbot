"""
RAG Document Chatbot
---------------------
A beginner-friendly Retrieval-Augmented Generation chatbot built with:
- Streamlit (frontend)
- Groq API (LLM answer generation)
- Hugging Face Sentence Transformers (embeddings)
- FAISS (vector database)
- pypdf (PDF text extraction)

Upload PDF/TXT documents, ask questions, and get answers grounded
ONLY in the content of the uploaded documents.
"""

import os
import io
import re
import uuid
import numpy as np
import streamlit as st
import faiss
from pypdf import PdfReader
from sentence_transformers import SentenceTransformer
from groq import Groq

# =========================================================
# 1. APPLICATION SETTINGS  (easy to change)
# =========================================================
# You can change the Groq model here. Use a currently supported model.
# See https://console.groq.com/docs/models for the up-to-date list.
GROQ_MODEL = "llama-3.3-70b-versatile"

# Lightweight, CPU-friendly Hugging Face embedding model.
EMBEDDING_MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"

# Chunking settings (characters, not tokens)
DEFAULT_CHUNK_SIZE = 900
DEFAULT_CHUNK_OVERLAP = 150

# Number of chunks retrieved per question
DEFAULT_TOP_K = 4

# Max file size guard (MB) - just a soft safety check
MAX_FILE_MB = 25


# =========================================================
# 2. GROQ API KEY HANDLING (never hardcode the key!)
# =========================================================
def get_groq_api_key():
    """
    Look for the Groq API key in this order:
    1. Streamlit secrets (used on Streamlit Community Cloud, or a local
       .streamlit/secrets.toml file)
    2. Environment variable GROQ_API_KEY (used in Colab / local terminal)
    Returns None if not found anywhere - the app will show a friendly error.
    """
    try:
        return st.secrets["GROQ_API_KEY"]
    except Exception:
        return os.getenv("GROQ_API_KEY")


# =========================================================
# 3. LOADING THE EMBEDDING MODEL (cached across users/sessions)
# =========================================================
@st.cache_resource(show_spinner=False)
def load_embedding_model():
    """
    Loads the Hugging Face sentence-transformer model once and reuses it
    for every user session. This model does NOT need an API key - it
    downloads automatically the first time it is used and is cached
    afterwards. This is safe to cache globally because the model itself
    is not user-specific; only the embeddings it produces are.
    """
    return SentenceTransformer(EMBEDDING_MODEL_NAME)


@st.cache_resource(show_spinner=False)
def load_groq_client(api_key):
    """Creates a Groq client once per unique API key."""
    return Groq(api_key=api_key)


# =========================================================
# 4. TEXT EXTRACTION
# =========================================================
def extract_text_from_pdf(file_bytes, file_name):
    """
    Extracts text page by page from a PDF file.
    Returns a list of dicts: {"text": ..., "source": file_name, "page": n}
    Detects password-protected, corrupted, or scanned (image-only) PDFs
    without crashing the app.
    """
    pages = []
    try:
        reader = PdfReader(io.BytesIO(file_bytes))
    except Exception as e:
        st.error(f"Could not open '{file_name}'. The file may be corrupted. ({e})")
        return pages

    if reader.is_encrypted:
        try:
            # Try opening with an empty password (common for "restricted"
            # rather than truly password-locked PDFs)
            reader.decrypt("")
        except Exception:
            st.error(
                f"'{file_name}' is password-protected. Please upload an "
                f"unlocked version of the file."
            )
            return pages

    extracted_any_text = False
    for page_num, page in enumerate(reader.pages, start=1):
        try:
            text = page.extract_text() or ""
        except Exception:
            text = ""
        text = text.strip()
        if text:
            extracted_any_text = True
            pages.append({"text": text, "source": file_name, "page": page_num})

    if not extracted_any_text:
        st.warning(
            f"⚠️ No extractable text was found in '{file_name}'. "
            f"This usually means it is a scanned/image-only PDF. "
            f"Ordinary text extraction cannot read scanned pages - "
            f"an OCR (Optical Character Recognition) step would be "
            f"needed to support this file, which is not included in "
            f"this basic project."
        )
    return pages


def extract_text_from_txt(file_bytes, file_name):
    """Extracts text from a plain .txt file. Returns list with one 'page'."""
    try:
        text = file_bytes.decode("utf-8", errors="ignore").strip()
    except Exception as e:
        st.error(f"Could not read '{file_name}' as text. ({e})")
        return []

    if not text:
        st.warning(f"⚠️ '{file_name}' appears to be empty. Skipping it.")
        return []

    return [{"text": text, "source": file_name, "page": 1}]


# =========================================================
# 5. TEXT CHUNKING
# =========================================================
def chunk_text(text, chunk_size, chunk_overlap):
    """
    Splits a long string into overlapping chunks.
    - chunk_size: how many characters go into each chunk
    - chunk_overlap: how many characters repeat between consecutive chunks
      (this preserves context that would otherwise be cut in half)
    """
    if chunk_overlap >= chunk_size:
        chunk_overlap = max(0, chunk_size // 4)

    chunks = []
    start = 0
    text_length = len(text)

    while start < text_length:
        end = min(start + chunk_size, text_length)
        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)
        if end == text_length:
            break
        start = end - chunk_overlap

    return chunks


def build_chunks_with_metadata(pages, chunk_size, chunk_overlap):
    """
    Takes extracted pages (with source/page info) and produces a flat list
    of chunk dicts, each carrying its own metadata:
    {"text", "source", "page", "chunk_id"}
    """
    all_chunks = []
    for page_info in pages:
        page_chunks = chunk_text(page_info["text"], chunk_size, chunk_overlap)
        for i, chunk in enumerate(page_chunks):
            all_chunks.append(
                {
                    "text": chunk,
                    "source": page_info["source"],
                    "page": page_info["page"],
                    "chunk_id": i,
                }
            )
    return all_chunks


# =========================================================
# 6. VECTOR DATABASE (FAISS)
# =========================================================
def create_vector_store(chunks, embed_model):
    """
    Converts chunk text into embeddings and builds a FAISS index.
    Returns (faiss_index, chunk_metadata_list) or (None, []) on failure.
    """
    if not chunks:
        return None, []

    try:
        texts = [c["text"] for c in chunks]
        embeddings = embed_model.encode(
            texts, show_progress_bar=False, convert_to_numpy=True
        )
        embeddings = np.asarray(embeddings, dtype="float32")

        # Normalize vectors so inner-product search behaves like cosine similarity
        faiss.normalize_L2(embeddings)

        dimension = embeddings.shape[1]
        index = faiss.IndexFlatIP(dimension)
        index.add(embeddings)

        return index, chunks
    except Exception as e:
        st.error(f"Failed to build the vector database: {e}")
        return None, []


def search_vector_store(query, embed_model, index, chunk_metadata, top_k):
    """
    Embeds the user's question and retrieves the top_k most similar chunks.
    Returns a list of chunk dicts (with a 'score' field added).
    """
    if index is None or not chunk_metadata:
        return []

    query_vec = embed_model.encode([query], convert_to_numpy=True).astype("float32")
    faiss.normalize_L2(query_vec)

    k = min(top_k, len(chunk_metadata))
    scores, indices = index.search(query_vec, k)

    results = []
    for score, idx in zip(scores[0], indices[0]):
        if idx == -1:
            continue
        item = dict(chunk_metadata[idx])
        item["score"] = float(score)
        results.append(item)
    return results


# =========================================================
# 7. RAG PROMPT + GROQ ANSWER GENERATION
# =========================================================
RAG_SYSTEM_PROMPT = """You are a careful, helpful document assistant.

INSTRUCTIONS:
- Answer the user's question using ONLY the information in the "Retrieved Context" below.
- Do not use outside knowledge and do not invent facts that are not supported by the context.
- If the answer is not present in the retrieved context, respond exactly with:
  "I could not find this information in the uploaded documents."
- You may use the conversation history only to understand what a follow-up question refers to,
  not as a source of factual information.
- Keep your answer clear, complete, and well organized.
- Where relevant, mention which part of the context supports your answer.
- Never claim information came from a document unless it appears in the retrieved context below.
"""


def build_user_prompt(question, retrieved_chunks, chat_history):
    """Builds the final prompt sent to the Groq model."""
    if retrieved_chunks:
        context_text = "\n\n".join(
            f"[Source: {c['source']}, Page {c['page']}]\n{c['text']}"
            for c in retrieved_chunks
        )
    else:
        context_text = "(No relevant context was retrieved.)"

    history_text = ""
    if chat_history:
        recent = chat_history[-6:]  # keep the prompt short
        history_text = "\n".join(
            f"{turn['role'].capitalize()}: {turn['content']}" for turn in recent
        )
    else:
        history_text = "(No previous conversation.)"

    return f"""Retrieved Context:
{context_text}

Conversation History:
{history_text}

User Question:
{question}

Answer:"""


def generate_answer(client, question, retrieved_chunks, chat_history, model_name):
    """Calls the Groq API and returns the generated answer text."""
    user_prompt = build_user_prompt(question, retrieved_chunks, chat_history)

    try:
        response = client.chat.completions.create(
            model=model_name,
            messages=[
                {"role": "system", "content": RAG_SYSTEM_PROMPT},
                {"role": "user", "content": user_prompt},
            ],
            temperature=0.2,
            max_tokens=1024,
        )
        return response.choices[0].message.content, None

    except Exception as e:
        err_text = str(e).lower()
        if "authentication" in err_text or "invalid api key" in err_text or "401" in err_text:
            return None, "Your Groq API key appears to be invalid. Please check it in Secrets."
        if "rate limit" in err_text or "429" in err_text:
            return None, "Groq's rate limit was reached. Please wait a moment and try again."
        if "model" in err_text and ("decommission" in err_text or "not found" in err_text):
            return None, (
                f"The model '{model_name}' is not available. It may be deprecated - "
                f"update GROQ_MODEL near the top of app.py to a current model."
            )
        if "timeout" in err_text:
            return None, "The request to Groq timed out. Please try again."
        return None, f"An unexpected error occurred while contacting Groq: {e}"


# =========================================================
# 8. FILE VALIDATION
# =========================================================
def validate_file(uploaded_file):
    """Basic checks before processing an uploaded file."""
    size_mb = uploaded_file.size / (1024 * 1024)
    if size_mb > MAX_FILE_MB:
        st.error(f"'{uploaded_file.name}' is too large ({size_mb:.1f} MB). Max is {MAX_FILE_MB} MB.")
        return False

    ext = uploaded_file.name.lower().split(".")[-1]
    if ext not in ("pdf", "txt"):
        st.error(f"'{uploaded_file.name}' has an unsupported format. Only PDF and TXT are allowed.")
        return False

    return True


# =========================================================
# 9. SESSION STATE INITIALIZATION
# =========================================================
def init_session_state():
    """
    Every user who opens the app gets their OWN independent copy of
    st.session_state. This guarantees one user's documents, vector
    index, and chat history are never visible to another user.
    """
    defaults = {
        "chat_history": [],          # list of {"role": "user"/"assistant", "content": str}
        "vector_index": None,        # this user's FAISS index
        "chunk_metadata": [],        # this user's chunk metadata list
        "processed_files": [],       # names of processed documents
        "kb_ready": False,           # has a knowledge base been built?
        "chunk_size": DEFAULT_CHUNK_SIZE,
        "chunk_overlap": DEFAULT_CHUNK_OVERLAP,
        "top_k": DEFAULT_TOP_K,
        "groq_model": GROQ_MODEL,
        "session_id": str(uuid.uuid4()),
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


def reset_knowledge_base():
    st.session_state.vector_index = None
    st.session_state.chunk_metadata = []
    st.session_state.processed_files = []
    st.session_state.kb_ready = False


def clear_chat():
    st.session_state.chat_history = []


# =========================================================
# 10. STREAMLIT UI
# =========================================================
def main():
    st.set_page_config(page_title="RAG Document Chatbot", page_icon="📄", layout="wide")
    init_session_state()

    st.title("📄 RAG Document Chatbot")
    st.caption(
        "Upload PDF or TXT documents, build a knowledge base, and ask questions. "
        "Answers are generated only from your uploaded documents using the Groq API."
    )

    api_key = get_groq_api_key()

    # ---------------- Sidebar ----------------
    with st.sidebar:
        st.header("⚙️ Settings")

        if not api_key:
            st.error(
                "GROQ_API_KEY was not found. Add it to Streamlit secrets "
                "(Settings → Secrets) or set it as an environment variable."
            )

        with st.expander("Advanced settings", expanded=False):
            st.session_state.chunk_size = st.number_input(
                "Chunk size (characters)", 300, 3000, st.session_state.chunk_size, 50
            )
            st.session_state.chunk_overlap = st.number_input(
                "Chunk overlap (characters)", 0, 800, st.session_state.chunk_overlap, 25
            )
            st.session_state.top_k = st.slider(
                "Chunks retrieved per question", 1, 10, st.session_state.top_k
            )
            st.session_state.groq_model = st.text_input(
                "Groq model name", st.session_state.groq_model
            )

        st.divider()
        st.subheader("📁 Upload Documents")
        uploaded_files = st.file_uploader(
            "Choose PDF or TXT files",
            type=["pdf", "txt"],
            accept_multiple_files=True,
        )

        if st.button("🚀 Process Documents", use_container_width=True):
            if not uploaded_files:
                st.warning("Please upload at least one file first.")
            else:
                process_documents(uploaded_files)

        st.divider()
        if st.session_state.kb_ready:
            st.success("Knowledge base is ready ✅")
            st.write("**Processed documents:**")
            for name in st.session_state.processed_files:
                st.write(f"- {name}")
        else:
            st.info("No knowledge base yet. Upload and process documents to begin.")

        st.divider()
        col1, col2 = st.columns(2)
        with col1:
            if st.button("🗑️ Clear Chat", use_container_width=True):
                clear_chat()
                st.rerun()
        with col2:
            if st.button("♻️ Reset Knowledge Base", use_container_width=True):
                reset_knowledge_base()
                st.rerun()

    # ---------------- Main chat area ----------------
    if not st.session_state.kb_ready:
        st.info(
            "👋 To get started: upload one or more PDF/TXT files in the sidebar, "
            "then click **Process Documents**. You'll be able to ask questions once "
            "the knowledge base is ready."
        )

    for turn in st.session_state.chat_history:
        with st.chat_message(turn["role"]):
            st.markdown(turn["content"])
            if turn.get("sources"):
                with st.expander("📚 Sources"):
                    for src in turn["sources"]:
                        st.markdown(f"- **{src['source']}** — Page {src['page']}")

    question = st.chat_input("Ask a question about your documents...")

    if question:
        handle_question(question, api_key)


def process_documents(uploaded_files):
    """Extracts, chunks, embeds, and indexes the uploaded documents."""
    with st.status("Processing documents...", expanded=True) as status:
        valid_files = [f for f in uploaded_files if validate_file(f)]
        if not valid_files:
            status.update(label="No valid files to process.", state="error")
            return

        st.write("📥 Extracting text...")
        all_pages = []
        for uploaded_file in valid_files:
            file_bytes = uploaded_file.read()
            ext = uploaded_file.name.lower().split(".")[-1]
            if ext == "pdf":
                pages = extract_text_from_pdf(file_bytes, uploaded_file.name)
            else:
                pages = extract_text_from_txt(file_bytes, uploaded_file.name)
            all_pages.extend(pages)

        if not all_pages:
            status.update(
                label="No text could be extracted from the uploaded files.",
                state="error",
            )
            return

        st.write("✂️ Splitting text into chunks...")
        chunks = build_chunks_with_metadata(
            all_pages, st.session_state.chunk_size, st.session_state.chunk_overlap
        )

        if not chunks:
            status.update(label="Text extraction produced no usable chunks.", state="error")
            return

        st.write(f"🧩 Created {len(chunks)} chunks.")

        st.write("🧠 Loading embedding model (first time may take a minute)...")
        try:
            embed_model = load_embedding_model()
        except Exception as e:
            status.update(label=f"Failed to load embedding model: {e}", state="error")
            return

        st.write("📊 Building vector database...")
        index, chunk_metadata = create_vector_store(chunks, embed_model)

        if index is None:
            status.update(label="Failed to build the vector database.", state="error")
            return

        st.session_state.vector_index = index
        st.session_state.chunk_metadata = chunk_metadata
        st.session_state.processed_files = list({f.name for f in valid_files})
        st.session_state.kb_ready = True

        status.update(label="✅ Knowledge base ready!", state="complete")


def handle_question(question, api_key):
    """Runs retrieval + Groq generation for a single user question."""
    if not question.strip():
        st.warning("Please enter a question.")
        return

    if not st.session_state.kb_ready:
        st.warning("⚠️ Please upload and process documents before asking a question.")
        return

    if not api_key:
        st.error("GROQ_API_KEY is missing. Add it in Secrets before asking questions.")
        return

    st.session_state.chat_history.append({"role": "user", "content": question})
    with st.chat_message("user"):
        st.markdown(question)

    embed_model = load_embedding_model()
    retrieved = search_vector_store(
        question,
        embed_model,
        st.session_state.vector_index,
        st.session_state.chunk_metadata,
        st.session_state.top_k,
    )

    try:
        client = load_groq_client(api_key)
    except Exception as e:
        st.error(f"Could not create the Groq client: {e}")
        return

    with st.chat_message("assistant"):
        with st.spinner("Thinking..."):
            answer, error = generate_answer(
                client,
                question,
                retrieved,
                st.session_state.chat_history[:-1],
                st.session_state.groq_model,
            )

        if error:
            st.error(error)
            return

        st.markdown(answer)

        # De-duplicate sources for display
        seen = set()
        unique_sources = []
        for c in retrieved:
            key = (c["source"], c["page"])
            if key not in seen:
                seen.add(key)
                unique_sources.append({"source": c["source"], "page": c["page"]})

        if unique_sources:
            with st.expander("📚 Sources"):
                for src in unique_sources:
                    st.markdown(f"- **{src['source']}** — Page {src['page']}")

        st.session_state.chat_history.append(
            {"role": "assistant", "content": answer, "sources": unique_sources}
        )


if __name__ == "__main__":
    main()
